<?php
$servername 	= "localhost";
$username 		= "root";
$password 		= "";
$database 		= "hostingg_yodicomprof";
// $link = mysqli_connect($servername,$username,$passwor>d,$database);
$link = mysqli_connect($servername,$username,$password,$database);
?>